﻿using System;

namespace FifthClass
{
    class Fifth
    {
        static void Main(string[] args)
        {
            int a = 90;

            if (a >= 75)
            {
                Console.WriteLine("The grade is A.");
            }
            else if (a >= 65)
            {
                Console.WriteLine("The grade is B.");
            }
            else if (a >= 55)
            {
                Console.WriteLine("The grade is C.");
            }
            else if (a >= 35)
            {
                Console.WriteLine("The grade is S.");    
            }
            else
            {
                Console.WriteLine("The grade is F.");

            }

        }
    }
}