namespace WinFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncheck_Click(object sender, EventArgs e)
        {
            string sname = txtname.Text.Trim();
            double num;

            bool isNum = double.TryParse(sname, out num);

            if (isNum)
            {

                MessageBox.Show(num.ToString());
            }
            else
            {
                {
                    MessageBox.Show("Invalid Number");
                }
            }
        }
    }
}
