namespace CalcWithIF
{
    public partial class frmDCal : Form
    {
        public frmDCal()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txtone.Text = " ";
            txttwo.Text = " ";
            txtot.Text = " ";
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
            string sign = "+";
            lblSign.Text = sign;
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            string sign = "-";
            lblSign.Text = sign;
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            string sign = "X";
            lblSign.Text = sign;
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            string sign = "/";
            lblSign.Text = sign;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double ione = double.Parse(txtone.Text);
            double isecond = double.Parse(txttwo.Text);
            

            if (txtone.Text != " " && txttwo.Text != " ")
            {
                if (lblSign.Text == "+")
                {
                   double tot =  ione + isecond;
                    txtot.Text = tot.ToString();
                    MessageBox.Show("The Result is " + tot);
                }
                else if (lblSign.Text == "-")
                {
                    double tot = ione - isecond;
                    txtot.Text = tot.ToString();
                    MessageBox.Show("The Result is " + tot);
                }
                else if (lblSign.Text == "X")
                {
                    double tot = ione * isecond;
                    txtot.Text = tot.ToString();
                    MessageBox.Show("The Result is " + tot);
                }
                else if (lblSign.Text == "/")
                {
                    double tot = ione / isecond;
                    txtot.Text = tot.ToString("0.##");
                    MessageBox.Show("The Result is " + tot);
                }
                else
                {
                    MessageBox.Show("Values can't be 0!!!");
                }
            }
            else
            {
                MessageBox.Show("Pls enter values for both inputs!!!");
            }
        }
    }
}
