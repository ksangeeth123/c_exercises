﻿namespace CalcWithIF
{
    partial class frmDCal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDCal));
            txtone = new TextBox();
            txttwo = new TextBox();
            txtot = new TextBox();
            lblSign = new Label();
            lblEqual = new Label();
            btnSum = new Button();
            btnSub = new Button();
            btnMulti = new Button();
            btnDiv = new Button();
            linkLabel1 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            button1 = new Button();
            SuspendLayout();
            // 
            // txtone
            // 
            txtone.BackColor = Color.FromArgb(255, 255, 128);
            txtone.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtone.ForeColor = Color.FromArgb(0, 0, 192);
            txtone.Location = new Point(76, 59);
            txtone.Multiline = true;
            txtone.Name = "txtone";
            txtone.Size = new Size(100, 45);
            txtone.TabIndex = 0;
            // 
            // txttwo
            // 
            txttwo.BackColor = Color.FromArgb(255, 255, 128);
            txttwo.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txttwo.ForeColor = Color.FromArgb(0, 0, 192);
            txttwo.Location = new Point(258, 59);
            txttwo.Multiline = true;
            txttwo.Name = "txttwo";
            txttwo.Size = new Size(100, 45);
            txttwo.TabIndex = 1;
            // 
            // txtot
            // 
            txtot.BackColor = Color.FromArgb(255, 255, 128);
            txtot.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtot.ForeColor = Color.FromArgb(0, 0, 192);
            txtot.Location = new Point(429, 59);
            txtot.Multiline = true;
            txtot.Name = "txtot";
            txtot.Size = new Size(100, 45);
            txtot.TabIndex = 2;
            // 
            // lblSign
            // 
            lblSign.AutoSize = true;
            lblSign.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSign.ForeColor = Color.Blue;
            lblSign.Location = new Point(192, 71);
            lblSign.Name = "lblSign";
            lblSign.Size = new Size(0, 21);
            lblSign.TabIndex = 3;
            // 
            // lblEqual
            // 
            lblEqual.AutoSize = true;
            lblEqual.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEqual.ForeColor = Color.Blue;
            lblEqual.Location = new Point(383, 69);
            lblEqual.Name = "lblEqual";
            lblEqual.Size = new Size(21, 21);
            lblEqual.TabIndex = 4;
            lblEqual.Text = "=";
            // 
            // btnSum
            // 
            btnSum.BackColor = Color.FromArgb(128, 255, 128);
            btnSum.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSum.Location = new Point(76, 177);
            btnSum.Name = "btnSum";
            btnSum.Size = new Size(55, 41);
            btnSum.TabIndex = 5;
            btnSum.Text = "Sum";
            btnSum.UseVisualStyleBackColor = false;
            btnSum.Click += btnSum_Click;
            // 
            // btnSub
            // 
            btnSub.BackColor = Color.FromArgb(128, 255, 128);
            btnSub.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSub.Location = new Point(76, 233);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(55, 41);
            btnSub.TabIndex = 6;
            btnSub.Text = "Sub";
            btnSub.UseVisualStyleBackColor = false;
            btnSub.Click += btnSub_Click;
            // 
            // btnMulti
            // 
            btnMulti.BackColor = Color.FromArgb(128, 255, 128);
            btnMulti.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMulti.Location = new Point(148, 177);
            btnMulti.Name = "btnMulti";
            btnMulti.Size = new Size(55, 41);
            btnMulti.TabIndex = 7;
            btnMulti.Text = "X";
            btnMulti.UseVisualStyleBackColor = false;
            btnMulti.Click += btnMulti_Click;
            // 
            // btnDiv
            // 
            btnDiv.BackColor = Color.FromArgb(128, 255, 128);
            btnDiv.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDiv.Location = new Point(148, 233);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(55, 41);
            btnDiv.TabIndex = 8;
            btnDiv.Text = "/";
            btnDiv.UseVisualStyleBackColor = false;
            btnDiv.Click += btnDiv_Click;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(545, 353);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(26, 15);
            linkLabel1.TabIndex = 9;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Exit";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.AutoSize = true;
            linkLabel2.Location = new Point(577, 353);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(34, 15);
            linkLabel2.TabIndex = 10;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Clear";
            linkLabel2.LinkClicked += linkLabel2_LinkClicked;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 128, 0);
            button1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(209, 178);
            button1.Name = "button1";
            button1.Size = new Size(85, 96);
            button1.TabIndex = 11;
            button1.Text = "Calc";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // frmDCal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(651, 377);
            Controls.Add(button1);
            Controls.Add(linkLabel2);
            Controls.Add(linkLabel1);
            Controls.Add(btnDiv);
            Controls.Add(btnMulti);
            Controls.Add(btnSub);
            Controls.Add(btnSum);
            Controls.Add(lblEqual);
            Controls.Add(lblSign);
            Controls.Add(txtot);
            Controls.Add(txttwo);
            Controls.Add(txtone);
            HelpButton = true;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "frmDCal";
            Text = "Decision Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtone;
        private TextBox txttwo;
        private TextBox txtot;
        private Label lblSign;
        private Label lblEqual;
        private Button btnSum;
        private Button btnSub;
        private Button btnMulti;
        private Button btnDiv;
        private LinkLabel linkLabel1;
        private LinkLabel linkLabel2;
        private Button button1;
    }
}
