﻿using System;

namespace ConsoleApplication5
{
    class ConsoleApplication5
    {
        static void Main(string[] args)
        {
            int counter = 0;
            string result = "";

            while (counter < 10)
            {
                counter += 1;
                result += "\t" + counter + " \t" + Math.Pow(counter, 2) + "\n";
            }

            Console.WriteLine("1 through 10 and their squares:\n" + result);
        }
    }
}
