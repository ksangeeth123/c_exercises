namespace WinFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            DateTime dt1 = DateTime.Now;
            label1.Text = dt1.ToString();


        }



        private void button1_Click(object sender, EventArgs e)
        {




            //DateTime dt = dateTimePicker1.Value;
            // label1.Text = dt.ToLongDateString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DateTime dt2 = dateTimePicker1.Value;
            label5.Text = dt2.ToLongDateString();

            DateTime dt4 = DateTime.Now;

            int yearDifference = dt4.Year - dt2.Year;
            label7.Text = yearDifference.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label5.Text = "Birthday Placeholder";
            label7.Text = "Displaying Age";
        }
    }
}
