﻿using System;
using Xceed.Wpf.Toolkit;

namespace consoleApplication6
{
    class consoleApplication6
    {
        static void Main(string[] args)
        {
            bool moredata = true;

            while (moredata)
            {
                if (MessageBox.Show("Do you want anothe number?", "State Controlled loop", MessageBoxButtons.YesNo, MessageBoxIcon.Question)) == DialogResult.No
                {
                    moredata = false;
                }
            }
        }
    }
}