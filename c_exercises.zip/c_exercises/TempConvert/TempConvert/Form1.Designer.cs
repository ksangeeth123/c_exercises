﻿namespace TempConvert
{
    partial class frmTemp
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            rdb1 = new RadioButton();
            rdb2 = new RadioButton();
            label2 = new Label();
            txttemp = new TextBox();
            label3 = new Label();
            txtconvt = new TextBox();
            label4 = new Label();
            txtunit = new TextBox();
            btnconvert = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 40);
            label1.Name = "label1";
            label1.Size = new Size(46, 20);
            label1.TabIndex = 0;
            label1.Text = "Units";
            // 
            // rdb1
            // 
            rdb1.AutoSize = true;
            rdb1.Location = new Point(12, 87);
            rdb1.Name = "rdb1";
            rdb1.Size = new Size(33, 19);
            rdb1.TabIndex = 1;
            rdb1.TabStop = true;
            rdb1.Text = "C";
            rdb1.UseVisualStyleBackColor = true;
            rdb1.CheckedChanged += rdb1_CheckedChanged;
            // 
            // rdb2
            // 
            rdb2.AutoSize = true;
            rdb2.Location = new Point(12, 124);
            rdb2.Name = "rdb2";
            rdb2.Size = new Size(31, 19);
            rdb2.TabIndex = 2;
            rdb2.TabStop = true;
            rdb2.Text = "F";
            rdb2.UseVisualStyleBackColor = true;
            rdb2.CheckedChanged += rdb2_CheckedChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(142, 87);
            label2.Name = "label2";
            label2.Size = new Size(73, 15);
            label2.TabIndex = 3;
            label2.Text = "Temperature";
            label2.Click += label2_Click;
            // 
            // txttemp
            // 
            txttemp.Location = new Point(278, 83);
            txttemp.Name = "txttemp";
            txttemp.Size = new Size(111, 23);
            txttemp.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(142, 137);
            label3.Name = "label3";
            label3.Size = new Size(118, 15);
            label3.TabIndex = 5;
            label3.Text = "Convert Temperature";
            // 
            // txtconvt
            // 
            txtconvt.Location = new Point(278, 134);
            txtconvt.Name = "txtconvt";
            txtconvt.Size = new Size(111, 23);
            txtconvt.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(142, 197);
            label4.Name = "label4";
            label4.Size = new Size(29, 15);
            label4.TabIndex = 7;
            label4.Text = "Unit";
            // 
            // txtunit
            // 
            txtunit.Location = new Point(278, 189);
            txtunit.Name = "txtunit";
            txtunit.Size = new Size(111, 23);
            txtunit.TabIndex = 8;
            // 
            // btnconvert
            // 
            btnconvert.BackColor = Color.Lime;
            btnconvert.Location = new Point(12, 291);
            btnconvert.Name = "btnconvert";
            btnconvert.Size = new Size(81, 37);
            btnconvert.TabIndex = 9;
            btnconvert.Text = "CONVERT";
            btnconvert.UseVisualStyleBackColor = false;
            btnconvert.Click += btnconvert_Click;
            // 
            // frmTemp
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(469, 394);
            Controls.Add(btnconvert);
            Controls.Add(txtunit);
            Controls.Add(label4);
            Controls.Add(txtconvt);
            Controls.Add(label3);
            Controls.Add(txttemp);
            Controls.Add(label2);
            Controls.Add(rdb2);
            Controls.Add(rdb1);
            Controls.Add(label1);
            Name = "frmTemp";
            Text = "Temperature Converter";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private RadioButton rdb1;
        private RadioButton rdb2;
        private Label label2;
        private TextBox txttemp;
        private Label label3;
        private TextBox txtconvt;
        private Label label4;
        private TextBox txtunit;
        private Button btnconvert;
    }
}
