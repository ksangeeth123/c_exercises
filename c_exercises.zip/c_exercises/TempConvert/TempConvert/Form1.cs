namespace TempConvert
{
    public partial class frmTemp : Form
    {
        public frmTemp()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnconvert_Click(object sender, EventArgs e)
        {
            double temperature;

            if (!double.TryParse(txttemp.Text, out temperature))
            {
                MessageBox.Show("Invalid Temperature input. Please enter a number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (rdb1.Checked)
            {
                double fahrenheit = (temperature * 9 / 5) + 32;

                txtconvt.Text = fahrenheit.ToString();
                txtunit.Text = "F";
            }
            else if (rdb2.Checked)
            {
                double celsius = (temperature - 32) * 5 / 9;

                txtconvt.Text = celsius.ToString();
                txtunit.Text = "C";
            }
        }

        private void rdb1_CheckedChanged(object sender, EventArgs e)
        {
            txtconvt.Clear();
            txtunit.Clear();
        }

        private void rdb2_CheckedChanged(object sender, EventArgs e)
        {
            txtconvt.Clear();
            txtunit.Clear();
        }
    }
}
