namespace WinFormsApp3
{
    public partial class frmTask01 : Form
    {
        public frmTask01()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = int.Parse(txtone.Text);
            int y = int.Parse(txttwo.Text);

            int sum = x + y;

            lblot.Text = sum.ToString();
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            int x = int.Parse(txtone.Text);
            int y = int.Parse(txttwo.Text);

            int subs = x - y;
            lblot.Text = subs.ToString();
        }

        private void btnmulti_Click(object sender, EventArgs e)
        {
            int x = int.Parse(txtone.Text);
            int y = int.Parse(txttwo.Text);
            int multi = x * y;

            lblot.Text = multi.ToString();
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            double x = double.Parse(txtone.Text);
            double y = double.Parse(txttwo.Text);

            double div = x / y;
            lblot.Text = div.ToString();
        }

        private void btnclr_Click(object sender, EventArgs e)
        {
            txtone.Text = "";
            txttwo.Text = "";
            lblot.Text = "";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       /* private void Form1_Resize(object sender, EventArgs e)
        {
            btnsum.Width = this.Width / 2;
            btnsum.Height = this.Height / 10;

            btnsub.Width = this.Width / 2;
            btnsub.Height = this.Height / 10;

            btnmulti.Width = this.Width / 2;
            btnmulti.Height = this.Height / 10;

            btndiv.Width = this.Width / 2;
            btndiv.Height = this.Height / 10;

            btnclr.Width = this.Width / 2;
            btnclr.Height = this.Height / 10;
        }*/

    }
}
