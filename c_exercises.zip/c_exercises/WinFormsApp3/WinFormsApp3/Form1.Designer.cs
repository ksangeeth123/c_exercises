﻿namespace WinFormsApp3
{
    partial class frmTask01
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtone = new TextBox();
            txttwo = new TextBox();
            lblot = new Label();
            label1 = new Label();
            label2 = new Label();
            btnsum = new Button();
            btnsub = new Button();
            btnmulti = new Button();
            btndiv = new Button();
            btnclr = new Button();
            SuspendLayout();
            // 
            // txtone
            // 
            txtone.Location = new Point(189, 89);
            txtone.Name = "txtone";
            txtone.Size = new Size(282, 23);
            txtone.TabIndex = 0;
            // 
            // txttwo
            // 
            txttwo.Location = new Point(189, 135);
            txttwo.Name = "txttwo";
            txttwo.Size = new Size(282, 23);
            txttwo.TabIndex = 1;
            // 
            // lblot
            // 
            lblot.AutoSize = true;
            lblot.Font = new Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblot.ForeColor = Color.Blue;
            lblot.Location = new Point(332, 28);
            lblot.Name = "lblot";
            lblot.Size = new Size(0, 30);
            lblot.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(26, 89);
            label1.Name = "label1";
            label1.Size = new Size(113, 21);
            label1.TabIndex = 3;
            label1.Text = "First Number :";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(26, 133);
            label2.Name = "label2";
            label2.Size = new Size(137, 21);
            label2.TabIndex = 4;
            label2.Text = "Second Number :";
            // 
            // btnsum
            // 
            btnsum.BackColor = Color.Yellow;
            btnsum.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsum.Location = new Point(26, 214);
            btnsum.Name = "btnsum";
            btnsum.Size = new Size(75, 43);
            btnsum.TabIndex = 5;
            btnsum.Text = "+";
            btnsum.UseVisualStyleBackColor = false;
            btnsum.Click += button1_Click;
            // 
            // btnsub
            // 
            btnsub.BackColor = Color.Yellow;
            btnsub.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsub.Location = new Point(116, 214);
            btnsub.Name = "btnsub";
            btnsub.Size = new Size(75, 43);
            btnsub.TabIndex = 6;
            btnsub.Text = "-";
            btnsub.UseVisualStyleBackColor = false;
            btnsub.Click += btnsub_Click;
            // 
            // btnmulti
            // 
            btnmulti.BackColor = Color.Yellow;
            btnmulti.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnmulti.Location = new Point(208, 214);
            btnmulti.Name = "btnmulti";
            btnmulti.Size = new Size(75, 43);
            btnmulti.TabIndex = 7;
            btnmulti.Text = "*";
            btnmulti.UseVisualStyleBackColor = false;
            btnmulti.Click += btnmulti_Click;
            // 
            // btndiv
            // 
            btndiv.BackColor = Color.Yellow;
            btndiv.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btndiv.Location = new Point(301, 214);
            btndiv.Name = "btndiv";
            btndiv.Size = new Size(75, 43);
            btndiv.TabIndex = 8;
            btndiv.Text = "/";
            btndiv.UseVisualStyleBackColor = false;
            btndiv.Click += btndiv_Click;
            // 
            // btnclr
            // 
            btnclr.BackColor = Color.PaleGreen;
            btnclr.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnclr.Location = new Point(396, 214);
            btnclr.Name = "btnclr";
            btnclr.Size = new Size(75, 43);
            btnclr.TabIndex = 9;
            btnclr.Text = "Clr";
            btnclr.UseVisualStyleBackColor = false;
            btnclr.Click += btnclr_Click;
            // 
            // frmTask01
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(563, 341);
            Controls.Add(btnclr);
            Controls.Add(btndiv);
            Controls.Add(btnmulti);
            Controls.Add(btnsub);
            Controls.Add(btnsum);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblot);
            Controls.Add(txttwo);
            Controls.Add(txtone);
            Name = "frmTask01";
            Text = "Task01";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtone;
        private TextBox txttwo;
        private Label lblot;
        private Label label1;
        private Label label2;
        private Button btnsum;
        private Button btnsub;
        private Button btnmulti;
        private Button btndiv;
        private Button btnclr;
    }
}
