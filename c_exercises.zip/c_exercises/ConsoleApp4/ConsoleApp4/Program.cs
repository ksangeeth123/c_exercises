﻿using System;

namespace ConsoleApplication4
{
    class consoleApp4
    {
        static void Main (string[] args)
        {
            string inValue = "";
            int sum = 0;
            int number;

            Console.Write("This program will let you enter");
            Console.Write("value after value. To stop, enter");
            Console.WriteLine("Enter value (-99 to exit)");
            inValue = Console.ReadLine();

            while (inValue != "-99")
            {
                number = Convert.ToInt32(inValue);
                sum += number;
                Console.WriteLine("Enter value (-99 to exit)");
                inValue = Console.ReadLine();
            }
            Console.WriteLine("Total values entered {0}", sum);
            Console.ReadLine();
        }
    }
}