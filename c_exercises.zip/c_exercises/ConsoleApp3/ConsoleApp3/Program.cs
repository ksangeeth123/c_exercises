﻿using System;

namespace ConsoleApplication3
{
    class ConsoleApp3
    {
        static void Main(string[] args)
        {
            int num;
            int sum = 0;

            Console.WriteLine("Please enter a number:");
            num = Convert.ToInt32(Console.ReadLine());

            while (num>= 0 && num<=10)
            {
                sum += num;
                num++;
            }

            Console.WriteLine("Sum of values from input to 10 is: " + sum);
        }
    }
}
