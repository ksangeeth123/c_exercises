﻿namespace WinFormsApp4
{
    partial class frmsampleCalculator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblOt = new Label();
            txt1 = new TextBox();
            txt2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            btnsum = new Button();
            btnsub = new Button();
            btnmulti = new Button();
            btndiv = new Button();
            btnclr = new Button();
            btnext = new Button();
            SuspendLayout();
            // 
            // lblOt
            // 
            lblOt.AutoSize = true;
            lblOt.Font = new Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblOt.ForeColor = Color.Blue;
            lblOt.Location = new Point(467, 33);
            lblOt.Name = "lblOt";
            lblOt.Size = new Size(0, 30);
            lblOt.TabIndex = 0;
            // 
            // txt1
            // 
            txt1.Location = new Point(161, 112);
            txt1.Name = "txt1";
            txt1.Size = new Size(190, 23);
            txt1.TabIndex = 1;
            // 
            // txt2
            // 
            txt2.Location = new Point(161, 161);
            txt2.Name = "txt2";
            txt2.Size = new Size(190, 23);
            txt2.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(0, 0, 192);
            label1.Location = new Point(26, 118);
            label1.Name = "label1";
            label1.Size = new Size(92, 17);
            label1.TabIndex = 3;
            label1.Text = "First Number:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(0, 0, 192);
            label2.Location = new Point(26, 167);
            label2.Name = "label2";
            label2.Size = new Size(110, 17);
            label2.TabIndex = 4;
            label2.Text = "Second Number:";
            // 
            // btnsum
            // 
            btnsum.BackColor = Color.FromArgb(255, 128, 128);
            btnsum.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsum.Location = new Point(59, 260);
            btnsum.Name = "btnsum";
            btnsum.Size = new Size(77, 44);
            btnsum.TabIndex = 5;
            btnsum.Text = "+";
            btnsum.UseVisualStyleBackColor = false;
            btnsum.Click += btnsum_Click;
            // 
            // btnsub
            // 
            btnsub.BackColor = Color.Yellow;
            btnsub.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsub.Location = new Point(161, 260);
            btnsub.Name = "btnsub";
            btnsub.Size = new Size(77, 44);
            btnsub.TabIndex = 6;
            btnsub.Text = "-";
            btnsub.UseVisualStyleBackColor = false;
            btnsub.Click += btnsub_Click;
            // 
            // btnmulti
            // 
            btnmulti.BackColor = Color.FromArgb(128, 255, 255);
            btnmulti.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnmulti.Location = new Point(260, 260);
            btnmulti.Name = "btnmulti";
            btnmulti.Size = new Size(77, 44);
            btnmulti.TabIndex = 7;
            btnmulti.Text = "*";
            btnmulti.UseVisualStyleBackColor = false;
            // 
            // btndiv
            // 
            btndiv.BackColor = Color.FromArgb(192, 64, 0);
            btndiv.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btndiv.Location = new Point(355, 260);
            btndiv.Name = "btndiv";
            btndiv.Size = new Size(77, 44);
            btndiv.TabIndex = 8;
            btndiv.Text = "/";
            btndiv.UseVisualStyleBackColor = false;
            // 
            // btnclr
            // 
            btnclr.BackColor = Color.FromArgb(128, 255, 128);
            btnclr.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnclr.Location = new Point(59, 328);
            btnclr.Name = "btnclr";
            btnclr.Size = new Size(179, 44);
            btnclr.TabIndex = 9;
            btnclr.Text = "Clear";
            btnclr.UseVisualStyleBackColor = false;
            btnclr.Click += btnclr_Click;
            // 
            // btnext
            // 
            btnext.BackColor = Color.Red;
            btnext.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnext.Location = new Point(253, 328);
            btnext.Name = "btnext";
            btnext.Size = new Size(179, 44);
            btnext.TabIndex = 10;
            btnext.Text = "Exit";
            btnext.UseVisualStyleBackColor = false;
            btnext.Click += btnext_Click;
            // 
            // frmsampleCalculator
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(638, 384);
            Controls.Add(btnext);
            Controls.Add(btnclr);
            Controls.Add(btndiv);
            Controls.Add(btnmulti);
            Controls.Add(btnsub);
            Controls.Add(btnsum);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txt2);
            Controls.Add(txt1);
            Controls.Add(lblOt);
            Name = "frmsampleCalculator";
            Text = "Sample Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblOt;
        private TextBox txt1;
        private TextBox txt2;
        private Label label1;
        private Label label2;
        private Button btnsum;
        private Button btnsub;
        private Button btnmulti;
        private Button btndiv;
        private Button btnclr;
        private Button btnext;
    }
}
