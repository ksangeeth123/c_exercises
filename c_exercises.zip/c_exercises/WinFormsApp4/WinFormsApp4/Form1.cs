namespace WinFormsApp4
{
    public partial class frmsampleCalculator : Form
    {
        public frmsampleCalculator()
        {
            InitializeComponent();

        }

        private void btnsum_Click(object sender, EventArgs e)
        {
            double x = double.Parse(txt1.Text);
            double y = double.Parse(txt2.Text);

            double sum = x + y;
            lblOt.Text = sum.ToString();
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            double x = double.Parse(txt1.Text);
            double y = double.Parse(txt2.Text);

            double difference = x - y;

            lblOt.Text = difference.ToString();
        }

        private void btnclr_Click(object sender, EventArgs e)
        {
            txt1.Text = "";
            txt2.Text = "";
            lblOt.Text = "";
        }

        private void btnext_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
